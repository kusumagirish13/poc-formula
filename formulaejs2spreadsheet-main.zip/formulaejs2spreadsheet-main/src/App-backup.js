import * as React from 'react';
import "./App.css";
import { SpreadsheetComponent } from "@syncfusion/ej2-react-spreadsheet";

const App = () => {

    const spreadsheet = React.useRef<any>()
    const load = () => {
        fetch("http://localhost:8080/api/v1/getSampleFile") //fetch the remote url
            .then((response) => {
                response.blob().then((fileBlob) => {
                    var file = new File([fileBlob], "Sample.xlsx"); //convert the blob into file
                    spreadsheet.current.open({ file: file }); //open the file into spreadsheet
                });
            });
    }


    const beforeSave = (args: any) => {
        console.log(args);
        args.needBlobData = true;
        args.isFullPost = false;
    }

    const saveComplete = (args: any) => {
        console.log(args)
        console.log(args.blobData);
    }

    const fileMenuItemSelect = (args: any) => {

    }
    return (
        <SpreadsheetComponent
            ref={spreadsheet}
            allowOpen={true}
            openUrl="https://ej2services.syncfusion.com/production/web-services/api/spreadsheet/open"
            saveUrl="https://ej2services.syncfusion.com/production/web-services/api/spreadsheet/save"
            //fileMenuItemSelect={fileMenuItemSelect}
            created={load}
            beforeSave={beforeSave}
            saveComplete={saveComplete}>
        </SpreadsheetComponent>
    );

}
export default App