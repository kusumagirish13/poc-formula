export const TableTitle = [
    {
        id: 1,
        title: "Interest Amount"
    },
    {
        id: 2,
        title: "Principle Amount"
    },
    {
        id: 3,
        title: "Time period"

    },
     {
        id: 4,
        title: "Interest rate"
    },
    {
        id:5,
        title: "Sum"
    }
]

export const sampleData=[
    {
        "Item":"",
        "Quantity":"",
        "Price Per Unit":"",
        "total Cost": '=PRODUCT(C3,B3)',
    },
    {
        "Item": "",
        "Quantity": "",
        "Price Per Unit": "",
        "total Cost": '=PRODUCT(C4,B4)',
    },
    {
        "Item": "",
        "Quantity": "",
        "Price Per Unit": "",
        "total Cost": '=PRODUCT(C5,B5)',
    },
    {
        "Item": "",
        "Quantity": "",
        "Price Per Unit": "",
        "total Cost": '=PRODUCT(C6,B6)',
    },
    {
        "Item": "",
        "Quantity": "",
        "Price Per Unit": "",
        "total Cost": '=PRODUCT(C7,B7)',
    }
]